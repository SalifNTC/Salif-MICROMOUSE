void clearscreen();
int * movercursor(int **maze, int *posicao, char tecla); //  FUNCAO MOVERCURSOR É UMA APONTADOR

void cbreak();

void nocbreak();

int *up(int **maze, int *pos);
int *down(int **maze, int *pos);
int *right(int **maze, int *pos);
int *left(int **maze, int *pos);

int *mapa(int **maze);
