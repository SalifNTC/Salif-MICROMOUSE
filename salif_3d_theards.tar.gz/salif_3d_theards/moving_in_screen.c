#include <stdio.h>
#include <unistd.h>
#include <termios.h>
#include <stdlib.h>
#define COLUMNS 67
#define ROWS 32

struct termios oldtc;
struct termios newtc;

int direcaopos[4];
/*Cria estruturas termios para armazenar os parametros e
informações do terminal*/

//As minhas direcoes seram 5,10,15,20 para norte,sul,este,oeste.

char inic_cursor(int *pos){

    printf("\033[%d;%dH^",ROWS+2-pos[1],pos[0]);   //coloca o cursor na posição do S
    return 5;

}
void posicao_cursor(int *posicao){
  printf("\033[%d;%dH",ROWS+2-posicao[1],posicao[0]);
}

void clearscreen(){
  /*Esta função faz uso das ANSI escape sequences,
  sequências de bytes que ao serem impressas,
  são interpretadas pelo terminal como comandos
  e não como caratéres.*/
  //printf("\033[2J");
  system("clear");  // foi utilizado este com o objetivo de corrigir um bug

}

void cbreak() {
  /*
  Esta função coloca o terminal no modo cbreak ou rare,
  no qual o terminal interpreta um carater de cada vez,
  mas continua a reconhecer combinações de teclas de controlo,
  como Ctrl-C.
  */
  tcgetattr(STDIN_FILENO, &oldtc);
  /*Obtẽm os parâmetros/atributos associados ao
  terminal e coloca-os na struct termios oldtc*/
  newtc = oldtc; //Atribui o valor de oldtc a newtc.
  newtc.c_lflag &= ~(ICANON | ECHO);
  /*Modifica a flag c_lflag que controla o modo do terminal,
  e efetua um bitwise-and com o bitwise-not do bitwise-or das constantes ICANON
  e ECHO, efetivamente definindo o modo não-canónico e a não-ecoação dos carateres
  introduzidos.
  Com o modo canónico desativado, a input do utilizador é dada caratér a carater,
  sem necessidade de delimitadores como newline, entre outras coisas.
  Com ECHO desativado, os carateres introduzidos não são ecoados, ou escritos,
  no ecrã.*/
  tcsetattr(STDIN_FILENO, TCSANOW, &newtc);
  /*Define os atributos do terminal tal como definidos em newtc,
  ou seja, desativa o modo canónico e o eco*/
}

void nocbreak() {
  tcsetattr(STDIN_FILENO, TCSANOW, &oldtc);
  /*Repõe os atributos do terminal para aqueles obtidos no início do programa e
  guardados em oldtc.*/
  fflush(stdout);
}

int *frente(int **maze, int *posicao){

  if(direcaopos[2] == 5){
    posicao[1]++;                            //soma 1 à posição anterior
    if (maze[posicao[1]-1][posicao[0]-1] != 1){
      posicao[1]--;
      printf("\033[%d;%dH ",ROWS+2-posicao[1],posicao[0]);
      posicao[1]++;
      printf("\033[%d;%dH^",ROWS+2-posicao[1],posicao[0]);             // movimenta para cima
    }
    else{
      posicao[1]--;                          // caso a posição seguinte for uma parede é subtraido 1
    }                                    // à posição atual

    direcaopos[0] = posicao[0];
    direcaopos[1] = posicao[1];

    return direcaopos;                          // retorna a posição atual
  }
//////////////////////////////////////////////////////

  else if(direcaopos[2] == 10){
    posicao[1]--;
    if (maze[posicao[1]-1][posicao[0]-1] != 1){
      posicao[1]++;
      printf("\033[%d;%dH ",ROWS+2-posicao[1],posicao[0]);
      posicao[1]--;
      printf("\033[%d;%dHv",ROWS+2-posicao[1],posicao[0]);            // movimenta para baixo
    }
    else{
      posicao[1]++;
    }

    direcaopos[0] = posicao[0];
    direcaopos[1] = posicao[1];

    return direcaopos;
  }
//////////////////////////////////////////////////////

  else if(direcaopos[2] == 15){
    posicao[0]++;
    if (maze[posicao[1]-1][posicao[0]-1] != 1){
      posicao[0]--;
      printf("\033[%d;%dH ",ROWS+2-posicao[1],posicao[0]);
      posicao[0]++;
      printf("\033[%d;%dH>",ROWS+2-posicao[1],posicao[0]);             // movimenta para a direita
    }
    else{
      posicao[0]--;
    }

    direcaopos[0] = posicao[0];
    direcaopos[1] = posicao[1];

    return direcaopos;
  }
////////////////////////////////////////////////////////

  else{
    posicao[0]--;
    if (maze[posicao[1]-1][posicao[0]-1] != 1){
      posicao[0]++;
      printf("\033[%d;%dH ",ROWS+2-posicao[1],posicao[0]);
      posicao[0]--;
      printf("\033[%d;%dH<",ROWS+2-posicao[1],posicao[0]);           // movimenta para a esquerda
    }
    else{
      posicao[0]++;
    }

    direcaopos[0] = posicao[0];
    direcaopos[1] = posicao[1];

    return direcaopos;
  }
}


int *direita(int **maze, int *pos){
   if(direcaopos[2] == 5){
    direcaopos[2] = 15;
    printf("\033[%d;%dH>",ROWS+2-pos[1],pos[0]);
  }
  else if(direcaopos[2] == 10){
    direcaopos[2] = 20;
    printf("\033[%d;%dH<",ROWS+2-pos[1],pos[0]);
  }
  else if(direcaopos[2] == 15){
    direcaopos[2] = 10;
    printf("\033[%d;%dHv",ROWS+2-pos[1],pos[0]);
  }
  else{
    direcaopos[2] = 5;
    printf("\033[%d;%dH^",ROWS+2-pos[1],pos[0]);
  }

  direcaopos[0] = pos[0];
  direcaopos[1] = pos[1];

  return direcaopos;

}

int *esquerda(int **maze, int *pos){

   if(direcaopos[2] == 5){
    direcaopos[2] = 20;
    printf("\033[%d;%dH<",ROWS+2-pos[1],pos[0]);
  }
  else if(direcaopos[2] == 10){
    direcaopos[2] = 15;
    printf("\033[%d;%dH>",ROWS+2-pos[1],pos[0]);
  }
  else if(direcaopos[2] == 15){
    direcaopos[2] = 5;
    printf("\033[%d;%dH^",ROWS+2-pos[1],pos[0]);
  }
  else{
    direcaopos[2] = 10;
    printf("\033[%d;%dHv",ROWS+2-pos[1],pos[0]);
  }

  direcaopos[0] = pos[0];
  direcaopos[1] = pos[1];



  return direcaopos;




}

int *mapa(int **maze){
  int *pos;
  pos = malloc(sizeof(int*) * 2);

  for(int i=ROWS;i>=0;i--){           // calcula a posição do S (pisição inicial)
    for(int j = 0; j < COLUMNS; j++){
      if (maze[i][j] == 2){
        pos[0] = i+2;
        pos[1] = j;
      }
    }
  }


  direcaopos[0]=pos[0];
  direcaopos[1]=pos[1];
  direcaopos[2]=inic_cursor(pos);
  return direcaopos;

}
// a funcao recebe  tres parametros poisicao tecla e o maze
int * movercursor(int **maze, int *posicao, char tecla){

    switch(tecla){
      case 'w'://"cima"
      case 'W':
        posicao = frente(maze, posicao);
        break;
      case 'd'://"direita"
      case 'D':
        posicao = direita(maze, posicao);
        break;
      case 'a'://"esquerda"
      case 'A':
        posicao = esquerda(maze, posicao);
        break;
      }

	return posicao;
}
