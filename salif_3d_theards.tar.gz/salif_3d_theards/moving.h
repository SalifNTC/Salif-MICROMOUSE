void clearscreen();
int * movercursor(int **maze, int *posicao, char tecla); //  FUNCAO MOVERCURSOR É UMA APONTADOR

void cbreak();

void nocbreak();

int *frente(int **maze, int *pos,int *direcaopos);
int *direita(int **maze, int *pos,int *direcaopos);
int *esquerda(int **maze, int *pos,int *direcaopos);
int *posicao_cursor(int  *posicao);

int *mapa(int **maze);
