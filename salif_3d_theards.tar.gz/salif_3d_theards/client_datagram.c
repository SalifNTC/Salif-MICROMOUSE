#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include "moving.h"
#include "reading.h"
//Sending an Internet Domain Datagram

/*
* Here I send a datagram to a receiver whose name I get from the
* command line arguments. The form of the command line is:
* dgramsend hostname portnumber
*/
void main(int argc, char* argv[])
{
  int sock;
  struct sockaddr_in name;
  struct addrinfo *hp,hints;

  //struct hostent *hp, *gethostbyname();
  /* Create socket on which to send. */
  sock = socket(AF_INET,SOCK_DGRAM, 0);
  if (sock == -1) {
    perror("opening datagram socket");
    exit(1);
  }
  /*
  * Construct name, with no wildcards, of the socket to ‘‘send’’
  * to. gethostbyname returns a structure including the network
  * address of the specified host. The port number is taken from
  * the command line.
  */
  hints.ai_family = AF_UNSPEC;
  hints.ai_socktype = SOCK_DGRAM;
  hints.ai_flags = 0;
  hints.ai_protocol = 0;
  hints.ai_canonname = NULL;
  hints.ai_addr = NULL;
  hints.ai_next = NULL;

  int res = getaddrinfo(argv[1],argv[2],&hints,&hp);
  if (res != 0) {
    fprintf(stderr, "%s: getting address error\n", argv[1]);
    exit(2);
  }
  int n,len;char tecla[2];
  char buffer[1024];
  struct sockaddr_in server;
  /* Send message. */
   do{
	   cbreak();
		tecla[0]=getchar();
           nocbreak();
		tecla[1]='\0';

	  if (sendto(sock,tecla, sizeof(tecla) ,0, hp->ai_addr,hp->ai_addrlen) == -1)
	    perror("sending datagram message");
	//receiving a message from the server...
	  
	  n = recvfrom(sock, (char *)buffer, 1024,
		        MSG_WAITALL, (struct sockaddr *) &server,
		        &len);
	    buffer[n] = '\0';
	    printf("Server : %s\n", buffer);
	  
	   /*
	   if (maze[pos[1]-1][pos[0]-1] == 3){  //Se chegar à posição do G o jogo acaba
	      printf("\033[34;0HYOU WIN!");
	    }
*/
  } while (tecla[0]!='q' && tecla[0] != 'Q'); //Fazer isto atẽ o utilizador não premir a tecla q
  
  close(sock);
  exit(0 );
}
